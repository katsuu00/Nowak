
package com.example.notatniksharedpreferences;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText editTextNote;
    private TextView textViewStatus;
    private SharedPreferences preferences;

    private static final String PREFS_NAME = "NotatnikPrefs";
    private static final String NOTE_KEY = "zapisana_notatka";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNote = findViewById(R.id.editTextNote);
        textViewStatus = findViewById(R.id.textViewStatus);

        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonClear = findViewById(R.id.buttonClear);

        // Otwieramy pamięć ustawień aplikacji.
        preferences = getSharedPreferences(
                PREFS_NAME,
                MODE_PRIVATE
        );

        // Wczytujemy wcześniej zapisaną notatkę.
        String savedNote = preferences.getString(NOTE_KEY, "");
        editTextNote.setText(savedNote);

        if (!savedNote.isEmpty()) {
            textViewStatus.setText("Wczytano zapisaną notatkę.");
        }

        // Obsługa przycisku zapisu.
        buttonSave.setOnClickListener(v -> {
            String note = editTextNote.getText().toString();

            preferences.edit()
                    .putString(NOTE_KEY, note)
                    .apply();

            textViewStatus.setText("Notatka została zapisana.");
            Toast.makeText(
                    MainActivity.this,
                    "Zapisano notatkę",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Obsługa przycisku usuwania.
        buttonClear.setOnClickListener(v -> {
            preferences.edit()
                    .remove(NOTE_KEY)
                    .apply();

            editTextNote.setText("");
            textViewStatus.setText("Notatka została usunięta.");

            Toast.makeText(
                    MainActivity.this,
                    "Usunięto notatkę",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}
