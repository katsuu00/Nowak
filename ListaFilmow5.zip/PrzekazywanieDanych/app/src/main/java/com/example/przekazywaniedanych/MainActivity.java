
package com.example.przekazywaniedanych;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(v -> {
            String imie = etName.getText().toString().trim();

            if (imie.isEmpty()) {
                Toast.makeText(
                        MainActivity.this,
                        "Wpisz swoje imię!",
                        Toast.LENGTH_SHORT
                ).show();
            } else {
                Intent intent = new Intent(
                        MainActivity.this,
                        SecondActivity.class
                );

                intent.putExtra("IMIE", imie);

                startActivity(intent);
            }
        });
    }
}
