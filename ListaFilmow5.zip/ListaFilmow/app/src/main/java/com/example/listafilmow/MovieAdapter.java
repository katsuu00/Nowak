
package com.example.listafilmow;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MovieAdapter
        extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private final List<Movie> movieList;

    public MovieAdapter(List<Movie> movieList) {
        this.movieList = movieList;
    }

    public static class MovieViewHolder extends RecyclerView.ViewHolder {

        TextView tvMovieIcon;
        TextView tvMovieTitle;
        TextView tvMovieDescription;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);

            tvMovieIcon = itemView.findViewById(R.id.tvMovieIcon);
            tvMovieTitle = itemView.findViewById(R.id.tvMovieTitle);
            tvMovieDescription =
                    itemView.findViewById(R.id.tvMovieDescription);
        }
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_movie, parent, false);

        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull MovieViewHolder holder, int position) {

        Movie movie = movieList.get(position);

        holder.tvMovieIcon.setText(movie.getIcon());
        holder.tvMovieTitle.setText(movie.getTitle());
        holder.tvMovieDescription.setText(movie.getDescription());
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }
}
