
package com.example.listafilmow;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewMovies;
    private MovieAdapter movieAdapter;
    private List<Movie> movieList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewMovies = findViewById(R.id.recyclerViewMovies);

        movieList = new ArrayList<>();

        movieList.add(new Movie(
                "Incepcja",
                "Thriller science fiction o podróżach w snach.",
                "🎬"
        ));

        movieList.add(new Movie(
                "Interstellar",
                "Wyprawa kosmiczna w poszukiwaniu nowego domu.",
                "🚀"
        ));

        movieList.add(new Movie(
                "Skazani na Shawshank",
                "Historia przyjaźni, nadziei i wytrwałości.",
                "⭐"
        ));

        movieList.add(new Movie(
                "Matrix",
                "Programista odkrywa tajemnicę otaczającego świata.",
                "💻"
        ));

        movieList.add(new Movie(
                "Król Lew",
                "Historia młodego lwa i jego drogi do dorosłości.",
                "🦁"
        ));

        recyclerViewMovies.setLayoutManager(
                new LinearLayoutManager(this)
        );

        movieAdapter = new MovieAdapter(movieList);
        recyclerViewMovies.setAdapter(movieAdapter);
    }
}
