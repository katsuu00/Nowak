
package com.example.listafilmow;

public class Movie {

    private String title;
    private String description;
    private String icon;

    public Movie(String title, String description, String icon) {
        this.title = title;
        this.description = description;
        this.icon = icon;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getIcon() {
        return icon;
    }
}
