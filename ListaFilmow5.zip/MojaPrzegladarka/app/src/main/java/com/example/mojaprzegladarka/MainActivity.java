
package com.example.mojaprzegladarka;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView webView;
    private EditText editTextUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        editTextUrl = findViewById(R.id.editTextUrl);

        Button buttonGo = findViewById(R.id.buttonGo);
        Button buttonBack = findViewById(R.id.buttonBack);
        Button buttonForward = findViewById(R.id.buttonForward);
        Button buttonRefresh = findViewById(R.id.buttonRefresh);

        // Strony będą otwierane wewnątrz aplikacji.
        webView.setWebViewClient(new WebViewClient());

        // Ustawienia przeglądarki.
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        // Otwieranie adresu wpisanego przez użytkownika.
        buttonGo.setOnClickListener(v -> {
            String url = editTextUrl.getText()
                    .toString()
                    .trim();

            if (url.isEmpty()) {
                Toast.makeText(
                        MainActivity.this,
                        "Wpisz adres strony",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            // Jeśli użytkownik nie poda protokołu,
            // dodajemy HTTPS.
            if (!url.startsWith("https://")
                    && !url.startsWith("http://")) {
                url = "https://" + url;
            }

            editTextUrl.setText(url);
            webView.loadUrl(url);
        });

        // Powrót do poprzedniej strony.
        buttonBack.setOnClickListener(v -> {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                Toast.makeText(
                        MainActivity.this,
                        "Brak poprzedniej strony",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Przejście do następnej strony w historii.
        buttonForward.setOnClickListener(v -> {
            if (webView.canGoForward()) {
                webView.goForward();
            } else {
                Toast.makeText(
                        MainActivity.this,
                        "Brak następnej strony",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Ponowne wczytanie strony.
        buttonRefresh.setOnClickListener(v ->
                webView.reload()
        );

        // Wczytanie strony przy uruchomieniu aplikacji.
        webView.loadUrl("https://www.wikipedia.org");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
