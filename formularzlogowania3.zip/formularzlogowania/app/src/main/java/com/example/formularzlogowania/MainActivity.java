
package com.example.formularzlogowania;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String haslo = etPassword.getText().toString();

            if (email.isEmpty() || haslo.isEmpty()) {
                Toast.makeText(
                        MainActivity.this,
                        "Wypełnij wszystkie pola!",
                        Toast.LENGTH_SHORT
                ).show();

            } else if (!email.contains("@")) {
                Toast.makeText(
                        MainActivity.this,
                        "E-mail musi zawierać znak @!",
                        Toast.LENGTH_SHORT
                ).show();

            } else {
                Toast.makeText(
                        MainActivity.this,
                        "Witaj, " + email + "!",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}
