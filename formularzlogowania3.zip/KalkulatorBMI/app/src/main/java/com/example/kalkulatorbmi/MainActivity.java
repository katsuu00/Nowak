
package com.example.kalkulatorbmi;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etWeight;
    private EditText etHeight;
    private Button btnCalculate;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        btnCalculate.setOnClickListener(v -> obliczBMI());
    }

    private void obliczBMI() {
        String masaTekst = etWeight.getText().toString().trim();
        String wzrostTekst = etHeight.getText().toString().trim();

        if (masaTekst.isEmpty() || wzrostTekst.isEmpty()) {
            pokazBlad("Wypełnij oba pola!");
            return;
        }

        try {
            double masa = Double.parseDouble(
                    masaTekst.replace(',', '.')
            );

            double wzrostCm = Double.parseDouble(
                    wzrostTekst.replace(',', '.')
            );

            if (masa <= 0 || wzrostCm <= 0) {
                pokazBlad("Masa i wzrost muszą być większe od zera!");
                return;
            }

            double wzrostM = wzrostCm / 100.0;
            double bmi = masa / (wzrostM * wzrostM);

            String kategoria;

            if (bmi < 18.5) {
                kategoria = "Niedowaga";
            } else if (bmi < 25.0) {
                kategoria = "Waga prawidłowa";
            } else if (bmi < 30.0) {
                kategoria = "Nadwaga";
            } else {
                kategoria = "Otyłość";
            }

            String wynik = String.format(
                    Locale.getDefault(),
                    "Twoje BMI: %.2f\nKategoria: %s",
                    bmi,
                    kategoria
            );

            tvResult.setText(wynik);

        } catch (NumberFormatException e) {
            pokazBlad("Wpisz poprawne wartości liczbowe!");
        }
    }

    private void pokazBlad(String komunikat) {
        Toast.makeText(
                MainActivity.this,
                komunikat,
                Toast.LENGTH_SHORT
        ).show();
    }
}
