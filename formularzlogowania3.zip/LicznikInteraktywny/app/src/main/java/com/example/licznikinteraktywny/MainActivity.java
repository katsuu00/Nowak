package com.example.licznikinteraktywny;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

 private int licznik = 0;
private TextView tvCounter;
 private Button btnIncrease;
 private Button btnDecrease;

 @Override
 protected void onCreate(Bundle savedInstanceState) {
 super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);

 tvCounter = findViewById(R.id.tvCounter);
 btnIncrease = findViewById(R.id.btnIncrease);
btnDecrease = findViewById(R.id.btnDecrease);

 btnIncrease.setOnClickListener(v -> {
licznik++;
aktualizujLicznik();
});

 btnDecrease.setOnClickListener(v -> {
 licznik--;
aktualizujLicznik();
});
 }

private void aktualizujLicznik() {
tvCounter.setText(String.valueOf(licznik));
}
}